// 주어진 baseUrl 문자열 뒤에 필수 요청 변수인 api 의 key — value 값을 key=value 의 형태로 더하여요청 url을 만드시오. (URL에서 요청 변수는 & 문자로 구분)
const baseUrl =
  'http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json?'

const api = {
  key: 'API_KEY',
  targetDt: '20200115',
}

// answer
const requestUrl = Object.entries(api).reduce(function (acc, el) {
  return acc + `${el[0]}=${el[1]}&`
}, baseUrl)



// 배열에 담긴 중복된 이름을 {'이름': 수} 형태의 object로 반환하세요.
const names = ['harry', 'jason', 'tak', 'tak', 'justin']

// answer
const countedNames = names.reduce(function(acc, name) { 
  if (name in acc) {
    acc[name]++
  } else {
    acc[name] = 1
  }
  return acc
}, {})

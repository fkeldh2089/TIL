// 숫자가 담긴 배열로 각 숫자들의 제곱근이 들어있는 새로운 배열을 만드시오.
const newNumbers = [4, 9, 16]

// answer
const roots = newNumbers.map(Math.sqrt)
 

// images의 요소들의 height 값만 저장되어 있는 배열 heights 를 만드세요.
const images = [
  { height: '34px', width: '39px' },
  { height: '54px', width: '19px' },
  { height: '83px', width: '75px' },
]

// answer
const heights = images.map(function (image) {
  return image.height
})


// 속도(distance/time)를 저장하는 배열 speeds 를 만드세요.
const trips = [
  { distance: 34, time: 10 },
  { distance: 90, time: 50 },
  { distance: 59, time: 25 },
]

// answer
const speeds = trips.map(function (trip) {
  return trip.distance / trip.time
})


// 두 배열의 아이템을 객체로 결합한 comics 배열을 만드세요.
const brands = ['Marvel', 'DC']
const movies = ['IronMan', 'Batman']

// 예시 출력)
// [{ name: 'Marvel', hero: 'IronMan' }, { name: 'DC', hero: 'Batman' }]

// answers
const comics = brands.map((x, i) => {
  return { name: x, hero: movies[i] }
})
const comics_2 = brands.map((x, i) => ({ name: x, hero: movies[i] }))
